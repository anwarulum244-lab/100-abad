import React from 'react';
import {Composition} from 'remotion';
import {MainComposition} from './MainComposition';
import {TOTAL_FRAMES} from './data/timeline';
import {FPS, W, H} from './data/geo';
export const Root: React.FC = () => (
  <Composition id="Dokumenter100Abad" component={MainComposition} durationInFrames={TOTAL_FRAMES} fps={FPS} width={W} height={H} />
);
