import React from 'react';
import {interpolate, useCurrentFrame, Easing} from 'remotion';
import {CITIES, LAND, MOUNTS, SEAS, poly, proj, MAP_W, MAP_H, PX_LON, W, H} from '../data/geo';
import {SCENES, sec} from '../data/timeline';
import {cameraAt, cameraTransform, cityXY, sceneIndexAt} from './CameraMovement';
import {C, sans, serif} from '../theme';

const tone = {gold: '232,200,114', emerald: '47,158,122', rose: '180,83,63'};

export const CinematicMap: React.FC = () => {
  const f = useCurrentFrame();
  const cam = cameraAt(f);
  const idx = sceneIndexAt(f);
  const inv = 1 / cam.s;
  // wilayah kumulatif (blob lembut, BUKAN batas teritorial)
  const blobs: {k: string; r: number; t: keyof typeof tone; a: number}[] = [];
  SCENES.forEach((sc, i) => {
    if (i > idx) return;
    sc.reach?.forEach((r) => {
      const a = i < idx ? 1 : interpolate(f - sec(sc.start), [30, 120], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
      blobs.push({k: r.city, r: r.r, t: r.tone ?? 'gold', a});
    });
  });
  // Keep the map legible: show markers from the current scene and one
  // immediately preceding scene only. Retaining every historical label caused
  // the map to become crowded after several transitions.
  const markers: {k: string; a: number}[] = [];
  SCENES.forEach((sc, i) => {
    if (i > idx || i < idx - 1) return;
    sc.markers?.forEach((m) => {
      const a = interpolate(f - sec(sc.start) - sec(m.at), [0, 14], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
      if (a > 0) markers.push({k: m.city, a: i < idx ? 0.32 * a : a});
    });
  });
  const sc = SCENES[idx];
  const arrows = SCENES.slice(Math.max(0, idx - 1), idx + 1).flatMap((s, j, arr) => (s.arrows ?? []).map((a) => ({a, s, cur: s === SCENES[idx]})));
  return (
    <svg width={W} height={H} style={{position: 'absolute', inset: 0}}>
      <defs>
        <linearGradient id="seaG" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#11131b" /><stop offset="0.55" stopColor="#080b12" /><stop offset="1" stopColor="#020407" /></linearGradient>
        <linearGradient id="landG" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stopColor="#6f5b3c" /><stop offset="0.45" stopColor="#3b3024" /><stop offset="1" stopColor="#171711" /></linearGradient>
        {Object.entries(tone).map(([k, v]) => (
          <radialGradient id={'g-' + k} key={k}><stop offset="0" stopColor={`rgba(${v},0.55)`} /><stop offset="0.7" stopColor={`rgba(${v},0.22)`} /><stop offset="1" stopColor={`rgba(${v},0)`} /></radialGradient>
        ))}
      </defs>
      <rect width={W} height={H} fill="url(#seaG)" />
      <g transform={cameraTransform(cam)}>
        <rect x={-2000} y={-2000} width={MAP_W + 4000} height={MAP_H + 4000} fill="url(#seaG)" />
        <polygon points={poly(LAND)} fill="url(#landG)" stroke="rgba(232,200,114,0.68)" strokeWidth={2.6 * inv} strokeLinejoin="round" style={{filter: 'drop-shadow(0 0 12px rgba(232,170,70,.18))'}} />
        {Object.entries(SEAS).map(([k, p]) => (
          <g key={k}>
            <polygon points={poly(p)} fill="none" stroke="rgba(232,200,114,0.16)" strokeWidth={14 * inv * cam.s} strokeLinejoin="round" />
            <polygon points={poly(p)} fill="url(#seaG)" stroke="rgba(232,200,114,0.48)" strokeWidth={2.2 * inv} strokeLinejoin="round" />
          </g>
        ))}
        {/* garis kontur topografi skematis */}
        {MOUNTS.map(([lo, la], i) => { const [x, y] = proj(lo, la); return (
          <g key={i} opacity={0.5} transform={`translate(${x},${y})`}>
            <path d="M-14,8 L-5,-10 L2,0 L8,-12 L16,8 Z" fill="rgba(15,13,12,0.62)" stroke="rgba(214,169,83,0.38)" strokeWidth={1} />
          </g>); })}
        {blobs.map((b, i) => { const [x, y] = cityXY(b.k); const pulse = 1 + 0.04 * Math.sin(f / 18 + i); return (
          <circle key={i} cx={x} cy={y} r={b.r * PX_LON * pulse * (0.6 + 0.4 * b.a)} fill={`url(#g-${b.t})`} opacity={b.a} />); })}
        {arrows.map(({a, s, cur}, i) => {
          const [x1, y1] = cityXY(a.from); const [x2, y2] = cityXY(a.to);
          const mx = (x1 + x2) / 2, my = (y1 + y2) / 2 - Math.hypot(x2 - x1, y2 - y1) * 0.18;
          const t = interpolate(f - sec(s.start) - sec(a.at), [0, sec(a.dur)], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp', easing: Easing.inOut(Easing.cubic)});
          if (t <= 0) return null;
          const len = 1;
          return (
            <g key={i} opacity={cur ? 1 : 0.5}>
              <path d={`M${x1},${y1} Q${mx},${my} ${x2},${y2}`} fill="none" pathLength={len} strokeDasharray={`${t} 2`} stroke={C.gold} strokeWidth={5 * inv} strokeLinecap="round" style={{filter: 'drop-shadow(0 0 6px rgba(232,200,114,.8))'}} />
            </g>);
        })}
        {markers.map((m, i) => { const [x, y] = cityXY(m.k); const nm = CITIES[m.k].n; return (
          <g key={i} opacity={m.a} transform={`translate(${x},${y})`}>
            <circle r={9 * inv * (1 + (1 - m.a) * 2)} fill="none" stroke={C.gold} strokeWidth={2 * inv} opacity={0.8 * (1 - m.a * 0.5)} />
            <circle r={4.5 * inv} fill={C.gold} />
            <text x={12 * inv} y={-10 * inv} fontFamily={sans} fontWeight={600} fontSize={26 * inv} letterSpacing={1 * inv} fill={C.text} stroke="rgba(10,6,2,0.85)" strokeWidth={5 * inv} paintOrder="stroke" style={{textTransform: 'uppercase'}}>{nm}</text>
          </g>); })}
      </g>
      <text x={W / 2} y={H - 396} textAnchor="middle" fontFamily={sans} fontSize={20} fill="rgba(232,200,114,0.42)" letterSpacing={1.5}>PETA ILUSTRATIF · CAKUPAN WILAYAH MENGIKUTI NARASI</text>
    </svg>
  );
};
