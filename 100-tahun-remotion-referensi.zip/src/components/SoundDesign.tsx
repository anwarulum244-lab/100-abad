import React from 'react';
import {Audio, Sequence, staticFile, interpolate} from 'remotion';
import {SCENES, sec, TOTAL_FRAMES} from '../data/timeline';

const sfx = (name: string) => staticFile(`sfx/${name}.wav`);

type HitProps = {at: number; dur: number; src: string; vol: number};
const Hit: React.FC<HitProps> = ({at, dur, src, vol}) => (
  <Sequence from={Math.max(0, at)} durationInFrames={dur} layout="none">
    <Audio src={src} volume={vol} />
  </Sequence>
);

/**
 * Minimal cinematic sound design.
 * Narration remains the focus: no continuous rumble/wind beds, no ticks on every
 * marker, and no whoosh for every scene. Only a small number of meaningful cues.
 */
export const SoundDesign: React.FC = () => {
  const cues: React.ReactNode[] = [];

  // Rare, intentional impacts for the opening and a few major historical turns.
  const impactScenes = new Set(['opening', 'tours']);
  const whooshScenes = new Set(['intro', 'timur', 'penutup']);
  const swellScenes = new Set(['opening']);

  SCENES.forEach((scene) => {
    const start = sec(scene.start);

    if (impactScenes.has(scene.id)) {
      cues.push(
        <Hit
          key={`${scene.id}-impact`}
          at={start + sec(scene.id === 'opening' ? 1.1 : 0.6)}
          dur={sec(1.8)}
          src={sfx(scene.id === 'opening' || scene.id === 'tours' ? 'impact_soft' : 'impact_deep')}
          vol={scene.id === 'opening' ? 0.14 : 0.10}
        />
      );
    }

    if (whooshScenes.has(scene.id)) {
      cues.push(
        <Hit
          key={`${scene.id}-whoosh`}
          at={Math.max(0, start - sec(0.18))}
          dur={sec(1.1)}
          src={sfx('whoosh_soft')}
          vol={0.055}
        />
      );
    }

    if (swellScenes.has(scene.id)) {
      cues.push(
        <Hit
          key={`${scene.id}-swell`}
          at={Math.max(0, sec(scene.end) - sec(2.2))}
          dur={sec(2.4)}
          src={sfx('swell_reverse')}
          vol={0.045}
        />
      );
    }
  });

  // Keep all cues modest. The voice-over is a separate master track at full level.
  // No always-on rumble/wind, per-marker ticks, arrow sweeps, or year chimes.
  return <>{cues}</>;
};
