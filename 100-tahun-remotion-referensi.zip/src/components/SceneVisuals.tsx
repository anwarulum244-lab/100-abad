import React from 'react';
import {AbsoluteFill, Easing, interpolate, random, useCurrentFrame} from 'remotion';
import {Scene, sec} from '../data/timeline';
import {C, arabic} from '../theme';
import {W, H} from '../data/geo';

const fade = (f: number, dur: number) => interpolate(f, [0, 20, dur - 24, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});

/** Close-up manuskrip: bingkai perkamen + kaligrafi teks Arab. Tidak menggambarkan tokoh secara visual. */
export const Manuscript: React.FC<{scene: Scene}> = ({scene}) => {
  const f = useCurrentFrame(); const dur = sec(scene.end) - sec(scene.start);
  const z = interpolate(f, [0, dur], [1.0, 1.14]);
  return (
    <AbsoluteFill style={{opacity: fade(f, dur) * 0.96, transform: `scale(${z})`}}>
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at 50% 40%, #e2cf9f, #b79b66 70%, #7d6137)'}} />
      <svg width={W} height={H} style={{position: 'absolute'}}>
        {[0, 1, 2].map((i) => <rect key={i} x={70 + i * 16} y={200 + i * 16} width={W - 140 - i * 32} height={H - 600 - i * 32} fill="none" stroke={`rgba(80,50,15,${0.7 - i * 0.2})`} strokeWidth={i === 0 ? 5 : 2} />)}
        {Array.from({length: 14}).map((_, i) => <circle key={i} cx={540} cy={900} r={90 + i * 34} fill="none" stroke="rgba(110,75,30,.14)" strokeWidth={2} strokeDasharray={`${4 + (i % 3) * 6} 9`} transform={`rotate(${f * (i % 2 ? 0.1 : -0.1)} 540 900)`} />)}
      </svg>
      <div style={{position: 'absolute', top: 560, width: '100%', textAlign: 'center', fontFamily: arabic, fontWeight: 700, fontSize: 150, color: '#3a2410', direction: 'rtl', opacity: interpolate(f, [10, 50], [0, 1], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'}), textShadow: '0 2px 0 rgba(255,240,200,.4)'}}>{scene.ar}</div>
    </AbsoluteFill>
  );
};

/** Siluet barisan pasukan di cakrawala + bukit pasir paralaks. Ilustrasi simbolik, bukan rekonstruksi. */
export const ArmySilhouette: React.FC<{scene: Scene}> = ({scene}) => {
  const f = useCurrentFrame(); const dur = sec(scene.end) - sec(scene.start);
  const o = interpolate(f, [0, 40, dur - 30, dur], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const dune = (amp: number, ph: number, base: number, sp: number, col: string) => {
    let d = `M0,${H}`; for (let x = 0; x <= W; x += 24) d += ` L${x},${base + Math.sin((x + f * sp) / 170 + ph) * amp + Math.sin((x - f * sp) / 61 + ph * 2) * amp * 0.25}`; return <path d={d + ` L${W},${H} Z`} fill={col} />;
  };
  const sunX = interpolate(f, [0, dur], [760, 520]);
  return (
    <AbsoluteFill style={{opacity: o * 0.9}}>
      <svg width={W} height={H} style={{position: 'absolute', bottom: 0}}>
        <defs><linearGradient id="sk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stopColor="#1a1020" stopOpacity="0" /><stop offset="0.55" stopColor="#8a4a2a" stopOpacity=".55" /><stop offset="1" stopColor="#e8a050" stopOpacity=".7" /></linearGradient></defs>
        <rect y={900} width={W} height={H - 900} fill="url(#sk)" />
        <circle cx={sunX} cy={1290} r={90} fill="#ffd89a" opacity={0.8} style={{filter: 'blur(6px)'}} />
        {dune(30, 0, 1360, 0.15, 'rgba(60,32,16,.7)')}
        <g fill="#0c0705" transform={`translate(${-f * 0.9},0)`}>
          {Array.from({length: 46}).map((_, i) => { const x = 40 + i * 52 + random('a' + i) * 18; const y = 1362 + Math.sin(x / 170) * 28; const h = 52 + random('h' + i) * 22; return (
            <g key={i} transform={`translate(${x},${y - h})`}>
              <rect x={-5} y={14} width={10} height={h - 14} /><circle cy={8} r={7} /><rect x={9} y={-24} width={3} height={h + 10} />
            </g>); })}
        </g>
        {dune(44, 2, 1460, 0.35, '#0c0705')}
      </svg>
    </AbsoluteFill>
  );
};
