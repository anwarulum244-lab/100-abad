import React from 'react';
import {AbsoluteFill, random, useCurrentFrame} from 'remotion';
import {W, H} from '../data/geo';
export const ParticleSystem: React.FC<{count?: number}> = ({count = 46}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      <svg width={W} height={H}>
        {Array.from({length: count}).map((_, i) => {
          const sp = 0.25 + random(`s${i}`) * 0.9; const x = (random(`x${i}`) * W + f * sp * 0.8) % W; const y = (random(`y${i}`) * H - f * sp * 0.5 + H * 2) % H;
          const r = 0.8 + random(`r${i}`) * 2.2; const tw = 0.25 + 0.35 * Math.sin(f / 20 + i);
          return <circle key={i} cx={x} cy={y} r={r} fill="#f3dca0" opacity={Math.max(0.05, tw) * 0.6} />;
        })}
      </svg>
    </AbsoluteFill>
  );
};
