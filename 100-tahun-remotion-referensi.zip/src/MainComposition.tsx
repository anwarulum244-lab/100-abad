import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {SCENES, sec, TOTAL_FRAMES} from './data/timeline';
import {CinematicMap} from './components/CinematicMap';
import {KineticTypography} from './components/KineticTypography';
import {Manuscript, ArmySilhouette} from './components/SceneVisuals';
import {ParticleSystem} from './components/ParticleSystem';
import {ColorGrading} from './components/ColorGrading';
import {SoundDesign} from './components/SoundDesign';
import {AudioMaster} from './components/AudioMaster';
import {C} from './theme';

export const MainComposition: React.FC = () => (
  <AbsoluteFill style={{background: C.ink}}>
    <CinematicMap />
    <ParticleSystem />
    {SCENES.map((s) => {
      const from = sec(s.start); const dur = Math.min(sec(s.end), TOTAL_FRAMES) - from;
      return (
        <Sequence key={s.id} from={from} durationInFrames={dur} name={s.id}>
          {s.visual === 'manuscript' && <Manuscript scene={s} />}
          {s.visual === 'army' && <ArmySilhouette scene={s} />}
          <KineticTypography scene={s} />
        </Sequence>);
    })}
    <ColorGrading total={TOTAL_FRAMES} />
    <AudioMaster />
    <SoundDesign />
  </AbsoluteFill>
);
