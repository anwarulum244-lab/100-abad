# 100 Tahun yang Mengubah Dunia — Remotion

- Composition ID: `Dokumenter100Abad`
- 1080×1920 (9:16), 30 fps, **6849 frame** = 228,284 dtk (diukur dari `public/100abad.mp3` dengan ffprobe)
- Output: `out/100-tahun.mp4` (H.264 + AAC)

## Render lewat GitHub Actions (cocok untuk HP Android)
1. Buat repo GitHub, unggah SELURUH isi folder ini (termasuk `package-lock.json`, `public/`, `.github/`). Lewat browser HP: Add file → Upload files (mode desktop site memudahkan).
2. Tab **Actions** → **Render video** → **Run workflow**.
3. Setelah hijau, buka run tersebut → bagian **Artifacts** → unduh `video-100-tahun` (berisi MP4 + 4 still pratinjau).
4. Jika merah: buka langkah yang gagal, salin log-nya dan kirim ke saya.

## Mengedit
- Semua waktu adegan ada di `src/data/timeline.ts` (detik). Ubah `start`/`end` bila ada adegan yang kurang pas dengan suara.
- Teks, penanda kota, panah arah, efek (`impact`, `whoosh`, `swell`) juga di file itu.
- SFX dibuat ulang dengan `python3 scripts/make_sfx.py` (deterministik).

## Struktur
`MainComposition` · `CinematicMap` · `CameraMovement` · `KineticTypography` · `SceneVisuals` (manuskrip & siluet) · `ParticleSystem` · `ColorGrading` · `SoundDesign` · `AudioMaster`

## Revisi kualitas (versi perbaikan)

- Sound design disederhanakan: tidak ada lagi rumble/angin terus-menerus, tick pada setiap marker, sweep pada setiap panah, atau chime pada setiap tahun. Impact dan whoosh hanya muncul pada beberapa transisi utama dengan level lebih rendah.
- Label peta lama dibatasi pada adegan saat ini dan adegan sebelumnya agar nama kota tidak menumpuk di layar.
- Peta tetap bersifat skematis; untuk akurasi geografis tingkat dokumenter, data garis pantai dan batas historis perlu diganti dengan dataset peta yang terverifikasi.

## Batas yang jujur
- Batas adegan diselaraskan dari jeda suara + proporsi karakter (tanpa ASR). Kemungkinan ada geser beberapa ratus ms; cek dengan still/pratinjau.
- Peta SKEMATIS buatan tangan, bukan data geografis presisi; wilayah berupa pendar lembut, panah = arah ekspansi ilustratif.
- Tidak ada musik latar (tidak ada aset berlisensi jelas). SFX prosedural, bukan rekaman.
- Nabi ﷺ dan tokoh tidak digambarkan secara visual.
